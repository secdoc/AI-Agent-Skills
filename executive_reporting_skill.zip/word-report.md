# Word report conventions

The Word report is the deliverable of record — the one that carries the full evidence chain. Produce it via the docx skill; this file specifies content and formatting conventions only, never document-generation mechanics.

## Formatting standard

- Calibri throughout.
- 11 pt body text.
- 1.15 line spacing.
- Page numbers on every page.
- Headings in the document's heading styles (so the docx skill's TOC and navigation work), sized modestly — this is a business report, not a poster.
- Data presented in real formatted tables with header rows, not tab-aligned text or pasted screenshots.

## Structure

1. **Executive summary — one page, stands alone.** Write it so a reader who stops after page one has the bottom line, the three-to-five findings that matter, the recommendation, and the ask. Test: cover every page after the first — does the reader still know what to decide and by when? If not, rewrite the summary.
2. **Findings.** Each finding is a short declarative statement followed by its supporting evidence. Numbers carry source IDs and, where time-sensitive, as-of dates ("headcount 214 as of July 31 [S2]").
3. **Implications.** What the findings mean against the plan, the budget, or the commitment. Every implication ties back to a stated finding.
4. **Recommendations.** What to do, in priority order, each with the finding(s) that justify it.
5. **Asks.** Decisions or resources needed, each with an owner and a deadline where the sources support one. Separate section, findable by a skimming reader in seconds.
6. **Source appendix.** The ingestion inventory, verbatim: ID, type, date, one-line summary. Add a freshness column or note where a source was flagged stale, and a short "Conflicts and resolutions" note if any sources disagreed — state which figure was used and why.

## Provenance in the report

Source IDs appear in the body next to the claims they support — bracketed inline [S2] or as footnotes, consistently one way throughout the document. The appendix is what makes the IDs resolvable. A number without a source ID should not survive review; if the number came from the user's own statement rather than a source, list the user's input as a source in the inventory ("S5 — user-provided figure, undated").

## Gaps and confidence

Where the report structure wants a figure the sources don't supply, the cell or sentence reads "not available in provided sources" — never a plausible placeholder. Thin evidence is labeled where it's used ("single source, vendor-reported"), not only in the appendix.

## Tables and figures

- Use a table when the point is precision or lookup (budget lines, milestone dates, risk register).
- Keep tables to the columns the reader needs; move reference-only columns to the appendix.
- Every table gets a one-line caption stating its takeaway, following the same discipline as slide titles: "Table 2: Two teams account for 87% of the overage [S2]."

## Relationship to the other deliverables

When produced in an "all three" run, this report is the master narrative. The email brief summarizes its executive summary; the deck presents its findings and asks. Numbers must match across all three exactly — reconcile before delivery, not after.
