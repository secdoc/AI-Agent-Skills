# Email brief conventions

The email brief is the shortest deliverable and the most likely to be read on a phone between meetings. Every convention here serves one goal: the reader gets the conclusion, the evidence shape, and the ask without scrolling.

## Subject line

The subject line states the conclusion, not the topic.

- Wrong: "Q3 Program Update"
- Right: "Q3 program: on track for Oct 15 launch; need vendor decision by Aug 12"

If the conclusion and the ask both fit, include both. The subject line follows the same takeaway-title discipline as slide titles.

## Length and shape

- Under ~300 words in the body. If the content won't fit, the content belongs in the Word report and the email summarizes it.
- Prose-first. Minimal formatting: a short bulleted list of key points is fine; nested bullets, headers, and bold-scatter are not.
- BLUF opening: the first sentence is the single most important finding or decision. No "I hope this finds you well," no background preamble.

## Structure

1. **Opening line** — the bottom line. One or two sentences.
2. **Key points** — three to five, each a short declarative sentence carrying a number and its implication. Freshness or confidence caveats attach directly to the point they qualify ("vendor's own figure, not independently confirmed").
3. **The ask** — explicit, with a deadline. "Need your sign-off on the vendor extension by Friday Aug 12; without it, cutover slips to September." If there is no ask, say what happens next instead ("no action needed; next update Aug 19").
4. **Pointer to detail** — one line deferring the specifics: "Full report attached" / "Detail and source list in the linked report."

## Provenance in an email

Source IDs stay out of the email body — an executive email with [S2] tags reads like a working draft. Provenance lives in the attached or linked report's source appendix. If the email stands alone (no attachment), add one closing line: "Sources: July spend export (7/31), vendor thread (7/25–8/1), steering notes (7/30)."

## Conflicts and gaps

If sources conflicted on a number that appears in the email, use the resolved figure and note the resolution in the attached report — not in the email body, unless the conflict itself is the news. If a key figure was not available in the sources, say so in the relevant key point rather than omitting the point silently.

## Example skeleton

> **Subject:** DR remediation slips two weeks; need budget exception approved by Aug 12
>
> The vendor's failed disaster-recovery test pushes remediation to Aug 22, two weeks past the committed date, and closing the gap requires a $40K budget exception that conflicts with the current tooling freeze.
>
> - Remediation cutover moves from Aug 8 to Aug 22 (vendor confirmed 8/1).
> - July uptime held at 99.92%, above the 99.9% SLA — the risk is forward-looking, not current.
> - The contracted SLA terms predate the July amendment; penalty exposure under the amended terms is not available in provided sources.
> - The $40K exception conflicts with the steering committee's Q4 tooling freeze (7/30 decision).
>
> **Ask:** approve the budget exception by Tuesday Aug 12, or the remediation slips into September. Full detail and sources in the attached report.
